/**
 * 파일명:ListExample.java <br/>
 * 생성일:2025-04-15 
 */
package com.pcwk.ehr.ex07;

import java.util.List;

public class Board {
	private String title;
	private String content;

	public Board(String title, String content) {
		super();
		this.title = title;
		this.content = content;
	}


	public String getTitle() {
		return title;
	}

	public String getContent() {
		return content;
	}
	
	
}
