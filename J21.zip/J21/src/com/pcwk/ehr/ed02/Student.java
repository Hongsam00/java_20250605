/**
 * 파일명:Student.java <br/>
 * 생성일:2025-04-15 
 */
package com.pcwk.ehr.ed02;

public class Student implements Comparable<Student> {
	
	private String name;
	
	private int score;

	public Student(String name, int score) {
		super();
		this.name = name;
		this.score = score;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	@Override
	public int compareTo(Student o) {
		if(this.score<o.score) {
			return -1;
		} else if(this.score == o.score) {
			return 0;
		} else {
			return 1;
		}
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", score=" + score + "]";
	}

}
