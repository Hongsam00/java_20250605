/**
 * 파일명:MapExample.java <br/>
 * 생성일:2025-04-15 
 */
package com.pcwk.ehr.ex09;

import java.util.*;
import java.util.Map.Entry;

public class MapExample {

	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("blue", 96);
		map.put("hong", 86);
		map.put("white", 92);
		
		String name = "";
		int maxScore = 0;
		int totalScore = 0;
		
		List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String,Integer>>(map.entrySet());
		
		//sort
		list.sort(new Comparator<Map.Entry<String, Integer>>() {

			@Override
			public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
				// TODO Auto-generated method stub
				return o1.getValue() - o2.getValue();
			}
		});
		
		for(Map.Entry<String, Integer> entry : list) {
			totalScore += entry.getValue();
			
		}
		double averageScore = (totalScore / (list.size() * 1.0));
		Map.Entry<String, Integer> entryMax = list.get(list.size()-1);
		
		System.out.println("점수 합계: " + totalScore);
		System.out.println("평균 점수: " + averageScore);
		System.out.println("최고 점수: " + entryMax.getValue());
		System.out.println("최고 점수를 받은 아이디: " + entryMax.getKey());
	}

}
