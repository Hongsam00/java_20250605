/**
 * 
 */
/**
 * 
 */
module J21 {
	requires org.apache.logging.log4j;
}