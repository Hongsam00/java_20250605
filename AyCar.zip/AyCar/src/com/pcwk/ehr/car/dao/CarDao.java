/**
 * Package Name : com.pcwk.ehr.book.dao <br/>
 * Class Name: BookDao.java <br/>
 * Description:  <br/>
 * Modification imformation : <br/> 
 * ------------------------------------------<br/>
 * 최초 생성일 : 2025-04-18<br/>
 *
 * ------------------------------------------<br/>
 * @author :user
 * @since  :2024-09-09
 * @version: 0.5
 */
package com.pcwk.ehr.car.dao;

import java.util.List;

import com.pcwk.ehr.cmn.PLog;
import com.pcwk.ehr.car.vo.CarVO;
import com.pcwk.ehr.cmn.Cardiv;
import com.pcwk.ehr.member.vo.MemberVO;

/**
 * 
 */
public class CarDao implements Cardiv<CarVO>, PLog {

	@Override
	public int doSave(CarVO dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public MemberVO doSelectOne(CarVO dto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<MemberVO> doRetrieve(CarVO dto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int doUpdate(CarVO dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int doDelete(CarVO dto) {
		// TODO Auto-generated method stub
		return 0;
	}

}
