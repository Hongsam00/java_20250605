/**
 * Package Name : com.pcwk.ehr.service <br/>
 * Class Name: AdminService.java <br/>
 * Description:  <br/>
 * Modification imformation : <br/> 
 * ------------------------------------------<br/>
 * 최초 생성일 : 2025-04-22<br/>
 *
 * ------------------------------------------<br/>
 * @author :user
 * @since  :2024-09-09
 * @version: 0.5
 */
package com.pcwk.ehr.service;

import java.util.List;
import java.util.Scanner;

import com.pcwk.ehr.member.dao.MemberDao;
import com.pcwk.ehr.member.vo.MemberVO;

public class AdminService {
	private MemberDao dao;

	/**
	 * @param dao
	 */
	public AdminService(MemberDao dao) {
		super();
		this.dao = dao;
	}

	// 관리자 메뉴
	public void adminMenu() {
		LoginService loginService = new LoginService();
		Scanner s = new Scanner(System.in);

		while (true) {
			System.out.println();
			System.out.println("╔════════════════════════════════════════╗");
			System.out.println("║         관리자 메뉴 (Admin Mode)   	 ║");
			System.out.println("╠════════════════════════════════════════╣");
			System.out.println("║  1. 회원 전체 조회                         ║");
			System.out.println("║  2. 회원 단건 조회                         ║");
			System.out.println("║  3. 회원 수정                         	 ║");
			System.out.println("║  4. 회원 삭제                           	 ║");
			System.out.println("║  5. 로그아웃 / 이전 메뉴                  	 ║");
			System.out.println("╚════════════════════════════════════════╝");
			System.out.print("▶ 번호를 선택하세요: ");

			int select = Integer.parseInt(s.nextLine());

			switch (select) {
			case 1:
				showAllMembers();
				break;
			case 2:
				System.out.println("※ 회원 단건 조회는 아직 구현되지 않았습니다.");
				break;
			case 3:
				System.out.println("※ 회원 수정은 아직 구현되지 않았습니다.");
				break;
			case 4:
				System.out.println("※ 회원 삭제는 아직 구현되지 않았습니다.");
				break;
			case 5:
				System.out.println("이전 메뉴로 돌아갑니다.");
				loginService.loginMenu();
				return;
			default:
				System.out.println("잘못된 입력입니다. 다시 선택해주세요.");
			}
		}
	}

	// 회원 전체 조회
	public void showAllMembers() {
		List<MemberVO> members = dao.doRetrieve(null);
		Scanner s = new Scanner(System.in);

		System.out.println("\n====== 회원 전체 목록 ======");
		for (MemberVO member : members) {
			System.out.println("ID: " + member.getId() + ", 이름: " + member.getName() + ", 권한: " + member.getRole());
		}
		System.out.println("===========================");
		while (true) {
			System.out.println("▶ 1. 뒤로가기");
			System.out.println("▶ 2. 종료");

			int select = Integer.parseInt(s.nextLine());

			switch (select) {
			case 1:
				adminMenu();
				break;
			case 2:
				System.exit(0);
				break;
			
			}

			s.close();
		}
	}

}
