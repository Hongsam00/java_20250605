/**
 * 
 */
/**
 * 
 */
module JMember {
	requires org.apache.logging.log4j;
}